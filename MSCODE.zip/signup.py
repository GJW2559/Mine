<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp</title>
    <center>注册到MSCODE</center>
    <center>
        <form action="">
            <input type="text" title="用户名">
            <br>
            <input type="password" title="密码">
            <input type="sumbit" value="注册" title="Sumbit">
        </form>
    </center>
</head>
<body>
    <center>注册到MSCODE</center>
    <center>
        <form action="">
            <input type="text" title="用户名">
            <br>
            <input type="password" title="密码">
            <input type="sumbit" value="注册" title="Sumbit">
        </form>
    </center>
</body>
</html>