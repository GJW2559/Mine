import turtle

p = turtle.Pen()
p.pensize(3)
p.pencolor('gold')

n = 6

for j in range(5):
    for i in range(n):
        p.forward(100)
        p.left(360/n)
    p.left(360/5)
    
turtle.done()